
!!!!! 注意，北航学报目前不接收LaTex稿件 !!!!!

## 亲试，上传了tex源文件以及pdf文件，收到回信：缺少稿件Word版。
# 希望本模板将来会有用

北航学报自然科学版LaTeX模板（非官方）

LaTeX Template (unofficial) for Journal of Beijing University of Aeronautics and Astronautics

模板是根据 “北航学报模板17.1.16” word版改的，非官方。最终格式解释权在北航学报，本工作只作为参考。

jbuaa.cls 模板文件

cite.sty、GB.cpx 引用样式、中文支持相关文件（文件内有原作者信息）

TempExample.tex 正文内容

TempExample.bib 参考文献

image 文件夹下是正文中用到的图片文件

在完整安装texlive 2016 或者 texlive 2017条件下，直接在命令行按顺序运行如下命令即可

xelatex TempExample.tex  
bibtex TempExample  
xelatex TempExample.tex  
xelatex TempExample.tex 

最终生成TempExample.pdf文件

#######################################################

Symbol 文件夹下是《变量符号说明》生成文档
增加了符号在文中的位置的信息，需要辅助文件TempExample.aux


![shot](shot.png)



