### 0.5.0
- Allow move function to return energy delta for efficiency gains in some cases (#28)

### 0.4.2
- Fix bug in load_state (#23)

### 0.4.1
- Allow any type of state variable
- copy_state() should not return None silently

### 0.4.0
- Tests running on python{2|3|pypy}
- fix auto method to return updates (#16)
